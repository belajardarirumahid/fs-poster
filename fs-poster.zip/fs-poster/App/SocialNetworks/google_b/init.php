<?php

use FSPoster\App\SocialNetworks\google_b\App\GoogleBusinessAddon;

defined( 'ABSPATH' ) or exit;

GoogleBusinessAddon::init();