<?php

use FSPoster\App\SocialNetworks\medium\App\MediumAddon;

defined( 'ABSPATH' ) or exit;

MediumAddon::init();