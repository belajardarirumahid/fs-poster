<?php

use FSPoster\App\SocialNetworks\reddit\App\RedditAddon;

defined( 'ABSPATH' ) or exit;

RedditAddon::init();