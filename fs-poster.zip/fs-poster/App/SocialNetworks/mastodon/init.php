<?php

use FSPoster\App\SocialNetworks\mastodon\App\MastodonAddon;

defined( 'ABSPATH' ) or exit;

MastodonAddon::init();