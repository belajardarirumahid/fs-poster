<?php

use FSPoster\App\SocialNetworks\instagram\App\InstagramAddon;

defined( 'ABSPATH' ) or exit;

InstagramAddon::init();