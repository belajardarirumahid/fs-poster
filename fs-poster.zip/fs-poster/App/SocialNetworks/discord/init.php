<?php

use FSPoster\App\SocialNetworks\discord\App\DiscordAddon;

defined( 'ABSPATH' ) or exit;

DiscordAddon::init();