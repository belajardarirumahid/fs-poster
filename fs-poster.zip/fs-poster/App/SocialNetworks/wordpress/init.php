<?php

use FSPoster\App\SocialNetworks\wordpress\App\WordpressAddon;

defined( 'ABSPATH' ) or exit;

WordpressAddon::init();