<?php

use FSPoster\App\SocialNetworks\ok\App\OdnoKlassnikiAddon;

defined( 'ABSPATH' ) or exit;

OdnoKlassnikiAddon::init();