<?php

use FSPoster\App\SocialNetworks\xing\App\XingAddon;

defined( 'ABSPATH' ) or exit;

XingAddon::init();