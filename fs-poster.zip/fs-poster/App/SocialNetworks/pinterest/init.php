<?php

use FSPoster\App\SocialNetworks\pinterest\App\PinterestAddon;

defined( 'ABSPATH' ) or exit;

PinterestAddon::init();