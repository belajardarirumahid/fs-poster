<?php

use FSPoster\App\SocialNetworks\tumblr\App\TumblrAddon;

defined( 'ABSPATH' ) or exit;

TumblrAddon::init();