<?php

use FSPoster\App\SocialNetworks\planly\App\PlanlyAddon;

defined( 'ABSPATH' ) or exit;

PlanlyAddon::init();