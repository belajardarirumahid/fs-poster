<?php

use FSPoster\App\SocialNetworks\twitter\App\TwitterAddon;

defined( 'ABSPATH' ) or exit;

TwitterAddon::init();