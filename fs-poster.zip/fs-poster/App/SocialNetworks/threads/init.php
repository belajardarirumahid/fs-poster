<?php

use FSPoster\App\SocialNetworks\threads\App\ThreadsAddon;

defined( 'ABSPATH' ) or exit;

ThreadsAddon::init();