<?php

use FSPoster\App\SocialNetworks\linkedin\App\LinkedInAddon;

defined( 'ABSPATH' ) or exit;

LinkedInAddon::init();