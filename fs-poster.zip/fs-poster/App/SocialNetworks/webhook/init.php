<?php

use FSPoster\App\SocialNetworks\webhook\App\WebhookAddon;

defined( 'ABSPATH' ) or exit;

WebhookAddon::init();