<?php

use FSPoster\App\SocialNetworks\telegram\App\TelegramAddon;

defined( 'ABSPATH' ) or exit;

TelegramAddon::init();