<?php

use FSPoster\App\SocialNetworks\youtube_community\App\YoutubeCommunityAddon;

defined( 'ABSPATH' ) or exit;

YoutubeCommunityAddon::init();