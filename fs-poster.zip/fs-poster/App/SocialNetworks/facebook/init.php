<?php

use FSPoster\App\SocialNetworks\facebook\App\FacebookAddon;

defined( 'ABSPATH' ) or exit;

FacebookAddon::init();