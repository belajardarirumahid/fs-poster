<?php

use FSPoster\App\SocialNetworks\plurk\App\PlurkAddon;

defined( 'ABSPATH' ) or exit;

PlurkAddon::init();