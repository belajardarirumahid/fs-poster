<?php

use FSPoster\App\SocialNetworks\blogger\App\BloggerAddon;

defined( 'ABSPATH' ) or exit;

BloggerAddon::init();