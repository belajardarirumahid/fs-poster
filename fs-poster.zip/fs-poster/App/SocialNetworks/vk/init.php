<?php

use FSPoster\App\SocialNetworks\vk\App\VKontakteAddon;

defined( 'ABSPATH' ) or exit;

VKontakteAddon::init();